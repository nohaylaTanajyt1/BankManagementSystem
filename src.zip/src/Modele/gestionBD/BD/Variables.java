package Modele.gestionBD.BD;


public class Variables {
	static String NOMBD="CompteBancaire";
	static int PORT=3306;
	static String MOTDEPASS="password";
	static String SERVEUR="localhost";
	static String USER="root";
	static String DRIVER="com.mysql.jdbc.Driver";
}
