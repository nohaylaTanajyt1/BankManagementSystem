package Modele.gestionBD;

public enum TypeCompte {
    EPARGNE, COURANT

    }
